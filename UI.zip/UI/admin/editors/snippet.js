﻿Ext.widget({
    xtype:'mz-form-entity',
    title: 'snippet',
    items: [
        
         {
             fieldLabel: 'content',
             xtype: 'taco-htmleditor',
             name: 'content',
             enableFont: false
         }
    ]
});